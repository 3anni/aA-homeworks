class ApplicationMailer < ActionMailer::Base
  default from: '99catsadmin@appacademy.io'
  layout 'mailer'
end

